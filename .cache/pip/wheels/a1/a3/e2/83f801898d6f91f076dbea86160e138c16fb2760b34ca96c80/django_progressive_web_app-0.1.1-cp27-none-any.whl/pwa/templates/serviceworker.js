// Empty Service Worker implementation.  To use your own Service Worker, set the PWA_SERVICE_WORKER_PATH variable in
// settings.py
